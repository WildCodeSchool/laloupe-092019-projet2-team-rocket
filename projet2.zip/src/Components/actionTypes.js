export const SET_FRENCH = {type:"set_french"};
export const SET_ENGLISH = {type:"set_english"};
export const SET_CHARACTER = {type:"set_character"};
